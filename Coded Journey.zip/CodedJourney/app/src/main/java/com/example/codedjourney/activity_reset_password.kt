package com.example.codedjourney

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_reset_password : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)
    }
}