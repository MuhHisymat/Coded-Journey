package com.example.codedjourney.model

class VideoModel (
    var title:String?=null,
    var desc:String?=null,
    var url:String?=null
)